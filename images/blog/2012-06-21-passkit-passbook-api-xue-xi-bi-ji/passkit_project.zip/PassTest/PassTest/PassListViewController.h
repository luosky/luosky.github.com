//
//  PassListViewController.h
//  PassTest
//
//  Created by Luosky on 12-6-21.
//  Copyright (c) 2012年 Luosky@gmail.com All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PassListViewController : UITableViewController

@end
