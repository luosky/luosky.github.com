//
//  PassListViewController.m
//  PassTest
//
//  Created by Luosky on 12-6-21.
//  Copyright (c) 2012年 Luosky@gmail.com All rights reserved.
//

#import "PassListViewController.h"
#import <PassKit/PassKit.h>

@interface PassListViewController ()
@property (nonatomic,strong) PKPassLibrary *library;
@property (nonatomic,strong) NSArray       *passes;
@end

@implementation PassListViewController


- (void)passLibraryDidChange:(NSNotification*)notification{
    dispatch_async(dispatch_get_main_queue(), ^{
        self.passes = [self.library passes];
        [self.tableView reloadData];
    });
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"已有Pass列表";
    self.library = [[PKPassLibrary alloc] init];
    NSNotificationCenter *noteCenter = [NSNotificationCenter defaultCenter];
    [noteCenter addObserver:self
                   selector:@selector(passLibraryDidChange:)
                       name:PKPassLibraryDidChangeNotification
                     object:self.library];
    
    self.passes = [self.library passes];
    NSLog(@"%d",[[self.library passes]count]);
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.passes count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"passCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text = [(PKPass*)self.passes[indexPath.row] serialNumber];
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    PKPass *pass = self.passes[indexPath.row];
    if ([PKPassLibrary isPassLibraryAvailable]) {
        if([self.library containsPass:pass]){
            PKPass *passInLibrary = [self.library passWithPassTypeIdentifier:pass.passTypeIdentifier serialNumber:pass.serialNumber];
             [[UIApplication sharedApplication] openURL:[passInLibrary passURL]];
             NSLog(@"%@",[passInLibrary passURL]);
        }
    }
}

@end
