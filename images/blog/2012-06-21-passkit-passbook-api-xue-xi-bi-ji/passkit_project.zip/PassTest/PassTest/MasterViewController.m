//
//  MasterViewController.m
//  PassTest
//
//  Created by Luosky on 12-6-18.
//  Copyright (c) 2012年 Luosky@gmail.com All rights reserved.
//

#import "MasterViewController.h"
#import <PassKit/PassKit.h>

@interface MasterViewController ()
@property (nonatomic,strong) NSMutableArray *objects;
@property (nonatomic,strong) PKPassLibrary *library;

@end

@implementation MasterViewController

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"添加pass";

    self.objects = [[NSMutableArray alloc] initWithArray:@[ @"coupon_pass_4",@"coupon_pass_1",@"coupon_pass_2",@"coupon_pass_5" ]];
    self.library = [[PKPassLibrary alloc] init];
    NSNotificationCenter *noteCenter = [NSNotificationCenter defaultCenter];
    [noteCenter addObserver:self
                   selector:@selector(passLibraryDidChange:)
                       name:PKPassLibraryDidChangeNotification
                     object:self.library];
    
}

- (void)passLibraryDidChange:(NSNotification*)notification{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.objects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];

    NSString *passName = self.objects[indexPath.row];
    PKPass *pass = [self passNamed:passName];
    cell.textLabel.text = pass.serialNumber;
    if ([self.library containsPass:pass]) {
        cell.detailTextLabel.text = @"已安装";
    }else{
        cell.detailTextLabel.text = @"";
    }
    return cell;
}

- (PKPass*)passNamed:(NSString*) name{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:name ofType:@"pkpass"];
    PKPass *pass = [[PKPass alloc] initWithData:[[NSData alloc]initWithContentsOfFile:filePath] error:nil];
    return pass;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *passName = self.objects[indexPath.row];
    PKPass *pass = [self passNamed:passName];
    if ([PKPassLibrary isPassLibraryAvailable]) {

        if([self.library containsPass:pass]){
            PKPass *passInLibrary = [self.library passWithPassTypeIdentifier:pass.passTypeIdentifier serialNumber:pass.serialNumber];
            [self.library removePass:passInLibrary];
/*
            [[UIApplication sharedApplication] openURL:[passInLibrary passURL]];
            NSLog(@"%@",[passInLibrary passURL]);
 */
        }else{
            PKAddPassesViewController *detail = [[PKAddPassesViewController alloc] initWithPass:pass];
            [self presentViewController:detail animated:YES completion:^{
                
            }];
        }
        
    }
}

@end
