//
//  MasterViewController.h
//  PassTest
//
//  Created by Luosky on 12-6-18.
//  Copyright (c) 2012年 Luosky@gmail.com All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController

@end
